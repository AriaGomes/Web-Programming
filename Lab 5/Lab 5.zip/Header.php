<?php?>


<!Doctype html>
<html>
<div id="header">
<head>
    <title>Assignment 1</title>
    <link rel="stylesheet" href="StyleSheet.css"/>
       
    <table class="title">  
        <tr>
            <td class="title">
                <h1>
                    Computer Engineering Technology
                </h1>
                <h1>
                    Web Programming (CST8238)
                </h1>
            </td>
        </tr>
    </table>
     </head>
</div>
</html>
     

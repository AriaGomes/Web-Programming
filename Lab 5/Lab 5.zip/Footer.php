<?php?>

<!DOCTYPE html>
<html>
<div id="footer">
<footer>
    <table>
        <tr>
            <td>
                <?php echo STUDENTNUM ?>
            </td>
        </tr>
        
        <tr>
            <td><?php echo $firstName, " ", $lastName?> </td>
        </tr>
        <tr>
            <td>
                Aria.Gomes00@gmail.com
            </td>
        </tr>
    </table>
</footer>
</div>
</html>
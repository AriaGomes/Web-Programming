<?php
include "Header.php";
include "Menu.php";
?>

<!Doctype html>
<html>
    <div id="content">
       <table>
       <tr>
           <td>
               <h1>Lab 5</h1>
           </td>
       </tr>
       
       <tr>
       <td>
        <body>
           <?php
            define("STUDENTNUM","040878659");
            $firstName = "Aria";
            $middleName = "Avelino";
            $lastName = "Gomes";
            
            $string1 = "Hello World!! ";
            $string2 = "This is the first time I am using PHP!!";
            echo $string1.$string2;
            ?>
             </body>
        </td>
        </tr>
      </table>
    </div>
        
</html>


<?php
include "Footer.php";
?>
    <?php?>
        <!Doctype html>
         <html>
          <div id="menu">
    <menu>          
        <p class="link"> <a href="https://ariagomes.net/CST83238/Lab1/">Lab 1</a></p>
        <p class="link"> <a href="https://ariagomes.net/CST83238/Lab2/">Lab 2</a></p>
        <p class="link"> <a href="https://ariagomes.net/CST83238/Lab3/">Lab 3</a></p>
        <p class="link"> <a href="https://ariagomes.net/CST83238/Lab4/">Lab 4</a></p>
    </menu>
</div>
</html>
<?php?>
<!Doctype html>
<html>
<link rel="stylesheet" href="StyleSheet.css"/>
<div id="header">
<head>
    <title>Lab 6</title>
    <table class="title">  
        <tr>
            <td class="title">
                <h1>
                    Computer Engineering Technology
                </h1>
                <h1>
                    Web Programming (CST8238)
                </h1>
            </td>
        </tr>
    </table>
     </head>
</div>
</html>
     

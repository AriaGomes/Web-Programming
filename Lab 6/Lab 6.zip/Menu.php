<?php?>
        <!Doctype html>
<html>
<div id="menu">
    <menu>          
        <p class="link"> <a href="https://ariagomes.net/CST83238/Lab6/Random.php">Random</a></p>
        <p class="link"> <a href="https://ariagomes.net/CST83238/Lab6/Prime.php">Prime</a></p>
        <p class="link"> <a href="https://ariagomes.net/CST83238/Lab6/Pattern.php">Pattern</a></p>
    </menu>
</div>
</html>
<?php
define("STUDENTNUM","040878659");
$firstName = "Aria";
$middleName = "Avelino";
$lastName = "Gomes";
# Declared variables and constants used from lab 5
?>

<!DOCTYPE html>
<html>
<div id="footer">
<footer>
    <table>
        <tr>
            <td>
                <?php echo STUDENTNUM ?>
            </td>
        </tr>
        
        <tr>
            <td><?php echo $firstName, " ", $lastName?> </td>
        </tr>
        <tr>
            <td>
                Aria.Gomes00@gmail.com
            </td>
        </tr>
    </table>
</footer>
</div>
</html>
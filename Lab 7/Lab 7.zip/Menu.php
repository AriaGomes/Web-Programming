<?php?>
        <!DOCTYPE html>
<html>
<div id="menu">
    <menu>          
        <p class="link"> <a href="https://ariagomes.net/CST83238/Lab7/Arrays.php">Arrays</a></p>
        <p class="link"> <a href="https://ariagomes.net/CST83238/Lab7/Calculator.php">Calculator</a></p>
        <p class="link"> <a href="https://ariagomes.net/CST83238/Lab7/ArrayOfObjects.php">Array Of Objects</a></p>
    </menu>
</div>
</html>